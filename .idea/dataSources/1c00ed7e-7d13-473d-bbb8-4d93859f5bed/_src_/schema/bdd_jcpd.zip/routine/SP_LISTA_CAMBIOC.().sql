CREATE PROCEDURE SP_LISTA_CAMBIOC()
  BEGIN
SELECT 
  t_usuarios.USU_ID,
  t_usuarios.USU_NOMBRE,
  t_usuarios.USU_APELLIDO,
  t_usuarios.USU_CEDULA,
  t_usuarios.USU_PASWORD,
  t_usuarios.USU_ESTADO,
  t_usuarios.USU_EMAIL
FROM
  t_usuarios WHERE t_usuarios.USU_CCONTRASENIA=1;
COMMIT;
END;
