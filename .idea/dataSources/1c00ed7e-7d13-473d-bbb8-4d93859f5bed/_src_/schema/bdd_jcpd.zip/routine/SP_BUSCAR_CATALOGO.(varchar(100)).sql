CREATE PROCEDURE SP_BUSCAR_CATALOGO(IN TIPO VARCHAR(100))
  BEGIN
SET @TIPO=TIPO;
SELECT 
  t_catalogogeneral.ctg_descripcion,
  t_catalogotipos.ctp_tipo
FROM
  t_catalogotipos
  INNER JOIN t_catalogogeneral ON (t_catalogotipos.ctp_id = t_catalogogeneral.ctp_id) 
  WHERE t_catalogotipos.ctp_tipo=@TIPO;
END;
