CREATE PROCEDURE SP_INSERT_AUXCASO(IN CatalogoID INT, IN CasoID INT)
  BEGIN
SET @CatalogoID=CatalogoID;
SET @CasoID=CasoID;
INSERT INTO t_auxcaso(t_auxcaso.caso_id,t_auxcaso.ctg_id) VALUES(@CasoID,@CatalogoID);
COMMIT;
END;
