CREATE PROCEDURE SP_INSERT_DENUNCIANTE(IN Nombre   VARCHAR(30), IN Apellido VARCHAR(50), IN CI VARCHAR(10),
                                       IN FechaNa  DATE, IN edad INT, IN direccion VARCHAR(150), IN sector VARCHAR(50),
                                       IN telefono VARCHAR(10), IN email VARCHAR(20), IN observacion VARCHAR(150),
                                       IN casoID   INT, IN relacion VARCHAR(200))
  BEGIN
SET @Nombre=Nombre;
SET @Apellido=Apellido;
SET @CI=CI;
SET @FechaNa=FechaNa;
SET @edad=edad;
SET @relacion=relacion;
SET @direccion=direccion;
SET @sector=sector;
SET @telefono=telefono;
SET @email=email;            
SET @observacion=observacion;
SET @casoID=casoID;
  INSERT INTO t_denunciante(t_denunciante.DDEN_NOMBRE,t_denunciante.DDEN_APELLIDOS,
  t_denunciante.DDEN_CI,t_denunciante.DDEN_FECHANAC,t_denunciante.DDEN_EDAD,
  t_denunciante.DDEN_RELACAFECTADO,t_denunciante.DDEN_DIRECCION,
  t_denunciante.DDEN_SECTOR,t_denunciante.DDEN_TELEFONO,
t_denunciante.DDEN_EMAIL,t_denunciante.DDEN_OBSERVACION,t_denunciante.CASO_ID) VALUES
(@Nombre,@Apellido,@CI,@FechaNa,@edad,@relacion,@direccion,@sector,@telefono,@email,@observacion,@casoID);  
  COMMIT;
END;
