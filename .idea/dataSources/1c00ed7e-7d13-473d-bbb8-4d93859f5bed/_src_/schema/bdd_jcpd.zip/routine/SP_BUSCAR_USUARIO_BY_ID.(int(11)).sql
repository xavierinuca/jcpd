CREATE PROCEDURE SP_BUSCAR_USUARIO_BY_ID(IN ID_USER INT)
  BEGIN
SET @ID_USER=ID_USER;
SELECT 
  t_usuarios.USU_ID,
  t_usuarios.USU_NOMBRE,
  t_usuarios.USU_APELLIDO,
  t_usuarios.USU_CEDULA,
  t_usuarios.USU_PASWORD,
  t_usuarios.USU_ESTADO
FROM
  t_usuarios WHERE t_usuarios.USU_ID=@ID_USER;
END;
