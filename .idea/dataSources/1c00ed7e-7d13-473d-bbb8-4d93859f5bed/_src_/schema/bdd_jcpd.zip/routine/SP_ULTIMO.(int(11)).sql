CREATE PROCEDURE SP_ULTIMO(IN casoID INT)
  BEGIN
SET @casoID=casoID;
SELECT 
  t_casos.CASO_ID,
  t_casos.CASO_NUMCASO,
  t_casos.CASO_MOTIVO,
  t_casos.CASO_OBSERVACION,
  t_casos.CASO_ESTADO,
  t_casos.CASO_FECHAREG,
  t_casos.CASO_FECHINGRESO
FROM
  t_casos WHERE t_casos.CASO_ID=@casoID;
END;
