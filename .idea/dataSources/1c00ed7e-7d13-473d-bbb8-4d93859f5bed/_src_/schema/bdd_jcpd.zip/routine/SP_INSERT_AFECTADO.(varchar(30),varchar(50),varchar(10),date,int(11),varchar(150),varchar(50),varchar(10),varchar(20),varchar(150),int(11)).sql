CREATE PROCEDURE SP_INSERT_AFECTADO(IN Nombre   VARCHAR(30), IN Apellido VARCHAR(50), IN CI VARCHAR(10),
                                    IN FechaNa  DATE, IN edad INT, IN direccion VARCHAR(150), IN sector VARCHAR(50),
                                    IN telefono VARCHAR(10), IN email VARCHAR(20), IN observacion VARCHAR(150),
                                    IN casoID   INT)
  BEGIN
SET @Nombre=Nombre;
SET @Apellido=Apellido;
SET @CI=CI;
SET @FechaNa=FechaNa;
SET @edad=edad;
SET @direccion=direccion;
SET @sector=sector;
SET @telefono=telefono;
SET @email=email;            
SET @observacion=observacion;
SET @casoID=casoID;
  INSERT INTO t_datosafectado(t_datosafectado.DAF_NOMBRE,t_datosafectado.DAF_APELLIDO,
  t_datosafectado.DAF_CI,t_datosafectado.DAF_FECHADENAC,t_datosafectado.DAF_EDAD,
  t_datosafectado.DAF_DIRECCION,t_datosafectado.DAF_SECTOR,t_datosafectado.DAF_TELEFONO,
  t_datosafectado.DAF_EMAIL,t_datosafectado.DAF_OBSERVACION,t_datosafectado.CASO_ID) VALUES(@Nombre,
  @Apellido,@CI,@FechaNa,@edad,@direccion,@sector,@telefono,@email,@observacion,@casoID);  
  COMMIT;
END;
