CREATE PROCEDURE SP_INSERT_CASO(IN Ncaso VARCHAR(30), IN Motivo VARCHAR(200), IN Observacion VARCHAR(200))
  BEGIN
SET @Ncaso=Ncaso;
SET @Motivo=Motivo;
SET @Observacion=Observacion;
INSERT INTO t_casos(t_casos.CASO_NUMCASO,t_casos.CASO_MOTIVO
,t_casos.CASO_ESTADO,t_casos.CASO_OBSERVACION,t_casos.CASO_FECHAREG,t_casos.CASO_FECHINGRESO) 
VALUES(@Ncaso,@Motivo,1,@Observacion,NOW(),NOW());
COMMIT;
END;
